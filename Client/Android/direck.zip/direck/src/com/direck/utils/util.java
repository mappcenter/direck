package com.direck.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;


public class util {
	public static int ShareType = 0;
	public static int BeSharedType = 1;
	public static int BookmarkType = 2;
	
	public static String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }
	public static void moveMap(GoogleMap m,LatLng loc,int zoom){
		// Move the camera instantly tolocation with a zoom of 17.
		m.moveCamera(CameraUpdateFactory.newLatLngZoom(loc,
				zoom));
		// Zoom in, animating the camera.
		m.animateCamera(CameraUpdateFactory.zoomTo(zoom-2), 2000,
				null);
	}
}
