package com.direck.interfaces;


import android.widget.ImageView;

import android.widget.TextView;


public class ItemView {
	public ImageView imgView;
	public ImageView imgNew;
	public ImageView imgPlay;
	public TextView txtName;
	public TextView txtAddress;
	public TextView txtShareBy;
	public TextView txtCreateDate;
	public TextView txtShareByLabel;
	
	
	
}
