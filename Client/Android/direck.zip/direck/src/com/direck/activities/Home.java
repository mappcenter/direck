package com.direck.activities;

import java.util.ArrayList;

import com.direck.R;
import com.direck.adapters.ItemArrayAdapter;
import com.direck.models.Item;



import com.direck.sync.sync;
import com.direck.utils.util;


import android.os.Build;
import android.os.Bundle;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.support.v4.app.NavUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;

public class Home extends Activity {

	static private ArrayList<Item> items;
	static private ItemArrayAdapter arr;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		
		

		loadFilter();
		loadItemList();
		sync.syncContactToLocalDB(this);

		// Show the Up button in the action bar.
		// setupActionBar();
	}

	private void loadFilter() {
		Spinner spinner = (Spinner) findViewById(R.id.typeFilter);
		
		
		// Create an ArrayAdapter using the string array and a default spinner
		// layout
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
				this, R.array.ItemType, android.R.layout.simple_spinner_item);
		// Specify the layout to use when the list of choices appears
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		// Apply the adapter to the spinner
		spinner.setAdapter(adapter);
		spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> parent, View view,
					int pos, long id) {
				// An item was selected. You can retrieve the selected item
				// using
				// parent.getItemAtPosition(pos)
				arr.getFilter()
						.filter(parent.getItemAtPosition(pos).toString());
			}

			public void onNothingSelected(AdapterView<?> parent) {
				// Another interface callback
			}
		});
	}

	private void loadItemList() {
		items = new ArrayList<Item>();
		setItem();
		ListView lv = (ListView) findViewById(R.id.listItem);
		arr = new ItemArrayAdapter(this, R.layout.list_item, items);
		try {
			lv.setAdapter(arr);
			lv.setOnItemClickListener(new OnItemClickListener() {

				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {

					Item itm = (Item) items.get(position);
					itm.setViewStatus(true);
					
					Intent intent = new Intent(getApplicationContext(),
							ItemDetails.class);
					intent.putExtra("selectedItem", itm);
					startActivity(intent);
				}

			});

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}

	}

	public void shareNew(View view){
		Intent intent = new Intent(this,ShareItem.class);
		startActivity(intent);
		
	}
	
	public void setItem() {
		items = new ArrayList<Item>();
		Item item = new Item(0, 0, 0, util.ShareType, true, "name1 infomation", "address1 info", 48.87747,2.37245, "ABC",util.getDateTime());
		
		items.add(item);
		item = new Item(0, 0, 0, util.BeSharedType, false, "name2 infomation", "address2 info", 10.79815, 106.63218, "XYZ",util.getDateTime());
		items.add(item);
		item = new Item(0, 0, 0, util.BookmarkType, true, "name3 infomation", "address3 info", 10.75304, 106.64334, "AFK",util.getDateTime());
		items.add(item);
		item = new Item(0, 0, 0, util.ShareType, false, "name4 infomation", "address4 info", 10.72167, 106.65442, "RTY",util.getDateTime());
		items.add(item);
		item = new Item(0, 0, 0, util.BookmarkType, true, "name5 infomation", "address5 info", 10.68060, 106.70497, "NBV",util.getDateTime());
		items.add(item);
		item = new Item(0, 0, 0, util.BeSharedType, false, "name6 infomation", "address6 info", 10.68389, 106.79878, "QAS",util.getDateTime());
		items.add(item);
		item = new Item(0, 0, 0, util.ShareType, true, "name7 infomation", "address7 info", 21.03333, 105.85000, "UHN",util.getDateTime());
		items.add(item);
		

	}

	@Override
	public void onDestroy() {
		super.onDestroy(); // Always call the superclass

		// Stop method tracing that the activity started during onCreate()
		android.os.Debug.stopMethodTracing();
	}

	@Override
	public void onPause() {
		super.onPause(); // Always call the superclass method first

	}

	@Override
	public void onResume() {
		super.onResume(); // Always call the superclass method first
		arr.notifyDataSetChanged();
	}

	// save state information
	@Override
	public void onSaveInstanceState(Bundle savedInstanceState) {

		// Always call the superclass so it can save the view hierarchy state
		super.onSaveInstanceState(savedInstanceState);
	}

	// call after onCreate only if InstanceState are saved
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		// Always call the superclass so it can restore the view hierarchy
		super.onRestoreInstanceState(savedInstanceState);

	}

	/**
	 * Set up the {@link android.app.ActionBar}, if the API is available.
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	private void setupActionBar() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			getActionBar().setDisplayHomeAsUpEnabled(true);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// This ID represents the Home or Up button. In the case of this
			// activity, the Up button is shown. Use NavUtils to allow users
			// to navigate up one level in the application structure. For
			// more details, see the Navigation pattern on Android Design:
			//
			// http://developer.android.com/design/patterns/navigation.html#up-vs-back
			//
			NavUtils.navigateUpFromSameTask(this);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

}
