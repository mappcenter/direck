package com.direck.activities;

import com.direck.R;
import com.direck.R.layout;
import com.direck.R.menu;
import com.direck.models.Item;
import com.direck.utils.MyLocation;
import com.direck.utils.MyLocation.LocationResult;
import com.direck.utils.util;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationChangeListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import android.location.Location;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class ShareItem extends FragmentActivity {

	private GoogleMap map;
	static LatLng location;
	private Item newItem;
	MyLocation myloc;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_share_item);
		double customLat = 0;
		double customLon = 0;
		location = new LatLng(customLat, customLon);
		Intent in = getIntent();
		if (in != null) {
			customLat = in.getDoubleExtra("CustomLat", 0);
			customLon = in.getDoubleExtra("CustomLon", 0);
			location = new LatLng(customLat, customLon);
		}
		try {
			// Check status of Google Play Services
			int status = GooglePlayServicesUtil
					.isGooglePlayServicesAvailable(this);
			if (status != ConnectionResult.SUCCESS) {
				GooglePlayServicesUtil.getErrorDialog(status, this, 1).show();
			} else {
				map = ((SupportMapFragment) getSupportFragmentManager()
						.findFragmentById(R.id.ItemMap)).getMap();
				map.setMyLocationEnabled(true);
				//load custom location from user
				if (customLat != 0) {
					Marker customLocation = map.addMarker(new MarkerOptions()
							.position(location).title("Here"));
					customLocation.showInfoWindow();
					util.moveMap(map, location, 16);
				}else {
					//load current location of user
					LocationResult locationResult = new LocationResult(){
					    @Override
					    public void gotLocation(Location loc){
					        //Got the location!
					    	location = new LatLng(loc.getLatitude(), loc.getLongitude());
					    	util.moveMap(map, location, 16);
					    }
					};
					myloc=new MyLocation();
					myloc.getLocation(this, locationResult);
				}
				map.setOnMapClickListener(new OnMapClickListener() {
					@Override
					public void onMapClick(LatLng arg0) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(getApplicationContext(),
								PinOnMap.class);
						if (location !=null){
						intent.putExtra("LATloc", location.latitude);
						intent.putExtra("LONloc", location.longitude);
						}
						startActivity(intent);

					}
				});
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.share_item, menu);
		return true;
	}
	@Override
	public void onPause() {
		super.onPause(); // Always call the superclass method first
		if (myloc!=null){
			myloc.cancelTimer();
		}

	}
	boolean validate(){
		EditText txtName = (EditText) findViewById(R.id.txtItemName);
		if ( txtName.getText().toString().trim().length()==0){
			txtName.setError("Please input Name");
			 return false;
		}
		return true;
	}

	public void eventToFriend(View view) {
		if (validate()) {
			newItem = new Item();
			EditText txtName = (EditText) findViewById(R.id.txtItemName);
			newItem.setName(txtName.getText().toString());
			EditText txtAddress = (EditText) findViewById(R.id.txtItemAddress);
			newItem.setAddress(txtAddress.getText().toString());
			newItem.setLatLng(location.latitude, location.longitude);
			
			Intent intent = new Intent(getApplicationContext(), FriendList.class);
			intent.putExtra("typeShare", "new");
			intent.putExtra("Item", newItem);
			startActivity(intent);
		}
	}

}
