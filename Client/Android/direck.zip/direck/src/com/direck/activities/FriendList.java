package com.direck.activities;

import java.util.ArrayList;

import com.direck.R;
import com.direck.adapters.FriendArrayAdapter;
import com.direck.data.dao.DAOContact;
import com.direck.models.Friend;
import com.direck.models.Item;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class FriendList extends Activity {

	private DAOContact datasource;
	private FriendArrayAdapter friendAdapter;
	private Item ItmInfo;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_friend_list);
		Intent in = getIntent();
		String typeShare="";
		if (in !=null){
			typeShare = in.getStringExtra("typeShare");
			ItmInfo = in.getParcelableExtra("Item");
			if (typeShare.equals("new")){
				
			}else { //existed
				
			}
			
			 
		}

		// List<contact> values = datasource.getAllContacts();

		// use the SimpleCursorAdapter to show the
		// elements in a ListView

		// Generate list View from ArrayList
		displayListView();
		// setListAdapter(adapter);
	}

	public void share(View view) {
		StringBuffer responseText = new StringBuffer();
		responseText.append(" To Friend(s):\n");
		boolean noSelectedFriend=true;

		ArrayList<Friend> friendlist = friendAdapter.friendlist;
		for (int i = 0; i < friendlist.size(); i++) {
			Friend friend = friendlist.get(i);
			if (friend.isSelected()) {
				responseText.append("\n" + friend.getContactName() + "-"
						+ friend.getFriendID());
				noSelectedFriend = false;
			}
		}
		if (noSelectedFriend) {
			Toast.makeText(getApplicationContext(), "Please select at least 1 friend to share", Toast.LENGTH_LONG)
			.show();
			return;
		}
		String itemInfo = ItmInfo.getName() + "-" + ItmInfo.getAddress();
		itemInfo = itemInfo + "-" + ItmInfo.getLattitude() + "," + ItmInfo.getLongitude();
		Toast.makeText(getApplicationContext(), itemInfo , Toast.LENGTH_LONG)
		.show();
		
		Toast.makeText(getApplicationContext(), responseText, Toast.LENGTH_LONG)
				.show();
		
		Intent intent = new Intent(getApplicationContext(),Home.class);
		startActivity(intent);
	}

	private void displayListView() {

		// Array list of countries
		ArrayList<Friend> friendList = new ArrayList<Friend>();
		ListView lstFriend = (ListView) findViewById(R.id.listDBContact);

		datasource = new DAOContact(this);
		datasource.open();
		friendList = datasource.getFriendList();

		// create an ArrayAdaptar from the String Array
		friendAdapter = new FriendArrayAdapter(this, R.layout.list_friend,
				friendList);

		// Assign adapter to ListView
		lstFriend.setAdapter(friendAdapter);
		lstFriend.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub

			}
		});
		
		EditText filter = (EditText) findViewById(R.id.filterFriend);
		filter.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				friendAdapter.getFilter().filter(s);
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				
			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.friend_list, menu);
		return true;
	}

	@Override
	protected void onResume() {
		datasource.open();
		super.onResume();
	}

	@Override
	protected void onPause() {
		datasource.close();
		super.onPause();
	}

}
