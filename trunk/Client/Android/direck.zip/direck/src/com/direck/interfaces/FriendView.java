package com.direck.interfaces;

import android.widget.CheckBox;
import android.widget.TextView;

public class FriendView {
	public TextView friendName;
	public TextView friendPhone;
	public CheckBox friendID;
}
