package com.direck.activities;

import com.direck.R;
import com.direck.R.layout;
import com.direck.R.menu;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;

public class ShareItem extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_share_item);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.share_item, menu);
		return true;
	}
	
	
	public void eventToFriend(View view){
		Intent intent = new Intent(getApplicationContext(),FriendList.class);
		startActivity(intent);
	}

}
