package com.direck.activities;

import com.direck.R;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Menu;
import android.widget.TextView;

public class ItemDetails extends FragmentActivity {

static final LatLng namLAT = new LatLng(10.72973, 106.63722);
	
	static final LatLng KIEL = new LatLng(53.551, 9.993);
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_item_details);
		
		Intent in = getIntent();
		TextView txtName = (TextView)findViewById(R.id.ItemName);

		// Check Google Play Service Available
		try {
			// Check status of Google Play Services
			int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
		    if (status != ConnectionResult.SUCCESS) {
		        GooglePlayServicesUtil.getErrorDialog(status, this, 1).show();
		    }else {
		    	GoogleMap map = ((SupportMapFragment)  getSupportFragmentManager().findFragmentById(R.id.ItemMap))
			               .getMap();
		    	map.setMyLocationEnabled(true);
				 Marker nam = map.addMarker(new MarkerOptions().position(namLAT).title("MyHome"));
				 
				 Marker kiel = map.addMarker(new MarkerOptions().position(KIEL).title("Kiel").snippet("Kiel is cool").icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_launcher)));
				 
			    // Move the camera instantly to Nam home with a zoom of 15.
				 map.moveCamera(CameraUpdateFactory.newLatLngZoom(namLAT, 15));
			    // Zoom in, animating the camera.
				 map.animateCamera(CameraUpdateFactory.zoomTo(10), 2000, null);
		    }
		} catch (Exception e) {
		    Log.e("Error: GooglePlayServiceUtil: ", "" + e);
		}
		
		txtName.setText(in.getStringExtra("ItemName") );

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.item_details, menu);
		return true;
	}

}
