package com.direck.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


public class util {
	public static int ShareType = 0;
	public static int BeSharedType = 1;
	public static int BookmarkType = 2;
	
	public static String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }
}
