package com.direck.models;


public class Item {
	int accountID;
	int ItemID;
	int FriendID;
	int type;
	boolean ViewStatus;
	//more info
	String Name;
	String Address;
	double lattitude;
	double longitude;
	String shareby;
	String CreateDate;
	

	public Item() {

	}

	public Item(String name, String address, int type) {
		this.Name = name;
		this.Address = address;
		this.type = type;
	}
	

	public Item(int accountID, int itemID, int friendID, int type,
			boolean viewStatus, String name, String address, double lattitude,
			double longitude, String shareby, String createDate) {
		super();
		this.accountID = accountID;
		ItemID = itemID;
		FriendID = friendID;
		this.type = type;
		ViewStatus = viewStatus;
		Name = name;
		Address = address;
		this.lattitude = lattitude;
		this.longitude = longitude;
		this.shareby = shareby;
		this.CreateDate = createDate;
	}

	public String getCreateDate() {
		return CreateDate;
	}

	public void setCreateDate(String createDate) {
		CreateDate = createDate;
	}

	public String getName() {
		return Name;
	}

	
	
	public int getAccountID() {
		return accountID;
	}

	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}

	public int getItemID() {
		return ItemID;
	}

	public void setItemID(int itemID) {
		ItemID = itemID;
	}

	public int getFriendID() {
		return FriendID;
	}

	public void setFriendID(int friendID) {
		FriendID = friendID;
	}

	public boolean isViewStatus() {
		return ViewStatus;
	}

	public void setViewStatus(boolean viewStatus) {
		ViewStatus = viewStatus;
	}

	public double getLattitude() {
		return lattitude;
	}

	public void setLattitude(double lattitude) {
		this.lattitude = lattitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public String getShareby() {
		return shareby;
	}

	public void setShareby(String shareby) {
		this.shareby = shareby;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
}
