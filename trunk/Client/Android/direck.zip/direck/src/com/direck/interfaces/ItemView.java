package com.direck.interfaces;


import android.widget.ImageView;

import android.widget.TextView;


public class ItemView {
	public ImageView imgView;
	public ImageView imgNew;
	public TextView txtName;
	public TextView txtAddress;
	public TextView txtShareBy;
	public TextView txtCreateDate;
	
	
	/*
	public ItemView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		this.context = context;
		LayoutInflater li = (LayoutInflater)this.getContext()
		        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		        li.inflate(R.layout.list_item, this,true);
		imgView = (ImageView) findViewById(R.id.logo);
		txtName = (TextView) findViewById(R.id.ItemName);
		txtAddress = (TextView) findViewById(R.id.ItemAddress);
		
		
	}
	*/
}
