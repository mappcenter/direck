package com.direck.activities;

import java.util.ArrayList;

import com.direck.R;
import com.direck.activities.Home;
import com.direck.data.dao.DAOContact;
import com.direck.sync.sync;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.telephony.TelephonyManager;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

public class Register extends Activity {
	public static boolean debug = true;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);

		if (!debug) {
			// if isFirstRegister = true ( 1) then show register form else show
			// Home screen
			SharedPreferences sharedPref = this
					.getPreferences(Context.MODE_PRIVATE);
			int flag = 1;
			int isFirstRegister = sharedPref.getInt(
					getString(R.string.isFirstRegister), flag);

			if (isFirstRegister == 1) {
				setContentView(R.layout.activity_register);
			} else {
				// home screen
				Intent intent = new Intent(this, Home.class);
				startActivity(intent);
			}
		} else {
			// first register
			// get phone number
			loadUserPhoneNumber();
		}

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}

	/** Called when the user clicks the Send button */
	public void startDireck(View view) {
		// Do something in response to button
		// create account

		// upload contact

		// sync contact from mobile to Local db
		sync.syncContactToLocalDB(this);
		// sync contact from local mobile with server db

		// create friend list

		// if create transaction successfully then mark isFirstRegister = 0
		if (!debug) {
			SharedPreferences sharedPref = this
					.getPreferences(Context.MODE_PRIVATE);
			SharedPreferences.Editor editor = sharedPref.edit();
			editor.putInt(getString(R.string.isFirstRegister), 0);
			editor.commit();
		}
		// start home screen
		Intent intent = new Intent(this, Home.class);
		startActivity(intent);
	}

	public void loadUserPhoneNumber() {
		try {
			TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
			String number = tm.getLine1Number();
			EditText phone = (EditText) findViewById(R.id.phone_no);
			phone.setText(number);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	/*
	 * public void loadContact(View view) {
	 * 
	 * // load contact final ArrayList<String> arrContact = new
	 * ArrayList<String>(); ListView lstContact = (ListView)
	 * findViewById(R.id.listContact);
	 * 
	 * Cursor cursor = getContentResolver().query(
	 * ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null,
	 * null); while (cursor.moveToNext()) { String name = cursor
	 * .getString(cursor
	 * .getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
	 * 
	 * String phoneNumber = cursor .getString(cursor
	 * .getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
	 * arrContact.add(name + "-" + phoneNumber); } ArrayAdapter<String> adapter
	 * = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,
	 * arrContact);
	 * 
	 * lstContact.setAdapter(adapter);
	 * 
	 * 
	 * 
	 * }
	 */

}
