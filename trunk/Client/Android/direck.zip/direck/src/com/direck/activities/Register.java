package com.direck.activities;

import com.direck.R;
import com.direck.activities.Home;
import com.direck.sync.sync;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.telephony.TelephonyManager;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

public class Register extends Activity {
	public static boolean debug = true;
	LinearLayout progressLayout;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);

		if (!debug) {
			// if isFirstRegister = true ( 1) then show register form else show
			// Home screen
			SharedPreferences sharedPref = this
					.getPreferences(Context.MODE_PRIVATE);
			int flag = 1;
			int isFirstRegister = sharedPref.getInt(
					getString(R.string.isFirstRegister), flag);

			if (isFirstRegister == 1) {
				setContentView(R.layout.activity_register);
			} else {
				// home screen
				Intent intent = new Intent(this, Home.class);
				startActivity(intent);
			}
		} else {
			// first register
			// get phone number
			progressLayout = (LinearLayout) findViewById(R.id.progressbar_view);
			progressLayout.setVisibility(View.GONE);
			loadUserPhoneNumber();
		}

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}

	public boolean validate() {
		EditText txtPhone = (EditText) findViewById(R.id.phone_no);
		if (txtPhone.getText().toString().trim().length() <= 0) {
			txtPhone.setError("Please input phone number");
			return false;
		}
		EditText txtName = (EditText) findViewById(R.id.display_name);
		if (txtName.getText().toString().trim().length() <= 0) {
			txtName.setError("Please input display name");
			return false;
		}
		return true;
	}

	/** Called when the user clicks the Send button */
	public void startDireck(View view) {
		// boolean bSuccess= false;

		// bSuccess=register();
		if (validate()) {
			EditText txtPhone = (EditText) findViewById(R.id.phone_no);
			EditText txtName = (EditText) findViewById(R.id.display_name);
			//Synchronize
			new RegisterTask(txtPhone.getText().toString(),txtName.getText().toString()).execute();

			// if create transaction successfully then mark isFirstRegister = 0
			if (!debug) {
				SharedPreferences sharedPref = this
						.getPreferences(Context.MODE_PRIVATE);
				SharedPreferences.Editor editor = sharedPref.edit();
				editor.putInt(getString(R.string.isFirstRegister), 0);
				editor.commit();
			}

			// if (bSuccess) {
			// start home screen
			Intent intent = new Intent(this, Home.class);
			startActivity(intent);
			// }
		}
	}

	public boolean register() {
		// Do something in response to button
		// create account

		// upload contact

		// sync contact from mobile to Local db
		sync.syncContactToLocalDB(getApplicationContext());
		// sync contact from local mobile with server db

		// create friend list

		return true;
	}

	public void loadUserPhoneNumber() {
		try {
			TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
			String number = tm.getLine1Number();
			if (number == null)
				number = "";
			EditText phone = (EditText) findViewById(R.id.phone_no);
			phone.setText(number);
			if (number.length() == 0) {
				phone.requestFocus();
			} else {
				EditText user = (EditText) findViewById(R.id.display_name);
				user.requestFocus();
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	class RegisterTask extends AsyncTask<String, Integer, Boolean> {
		private String phoneNumber;
		private String displayName;

		public RegisterTask(String phone, String name) {
			phoneNumber = phone;
			displayName = name;
		}

		@Override
		protected void onPreExecute() {
			progressLayout.bringToFront();
			progressLayout.setBackgroundColor(Color.WHITE);
			progressLayout.setVisibility(View.VISIBLE);
			// listView.setVisibility(View.GONE);
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(Boolean result) {
			progressLayout.setVisibility(View.GONE);
			// listView.setVisibility(View.VISIBLE);
			// adapter.notifyDataSetChanged();
			super.onPostExecute(result);
		}

		@Override
		protected Boolean doInBackground(String... params) {

			register();
			try {
				Thread.sleep(5000);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
	}

}
